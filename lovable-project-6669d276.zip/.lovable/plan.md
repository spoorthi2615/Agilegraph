
# AgileGraph — Frontend Build Plan

Full pivot from the current kids-calculator project to a production-quality enterprise SaaS UI for post-quantum cryptography migration. Frontend only, no backend, no auth, no fake APIs — pure realistic mock data in a `src/lib/mock-data.ts` module.

## Design system

Rewrite `src/styles.css` for a clean, light enterprise look:
- Background `#F8FAFC`, cards pure white, primary `#2563EB`, success `#10B981`, warning `#F59E0B`, critical `#EF4444`, text `#111827`, muted `#6B7280`, borders `#E5E7EB`.
- Typography: Inter (headings + body), loaded via `<link>` in `__root.tsx` head.
- Tokens: `--radius` 16px, soft shadow tokens (`--shadow-sm/md/lg`), subtle glass utility (`bg-white/70 backdrop-blur border`).
- Global smooth transitions, focus rings, skeleton shimmer keyframes, fade-in / slide-up animations.
- Remove the calculator's playful tokens, keyframes, and Fredoka font.

## Route architecture

Convert to a shell layout with sticky sidebar + sticky header. The landing page stays a full-bleed marketing page (no shell); app routes render inside the shell.

```
src/routes/
  __root.tsx                 -> HTML shell, fonts, meta, QueryClient
  index.tsx                  -> Landing (full-bleed, own header/footer)
  _app.tsx                   -> App layout: sticky sidebar + sticky topbar + <Outlet/>
  _app.dashboard.tsx         -> Dashboard
  _app.scan.tsx              -> Scan Project
  _app.rankings.tsx          -> Risk Rankings
  _app.graph.tsx             -> Graph View
  _app.assets.$id.tsx        -> Asset Details
  _app.explainability.tsx    -> Explainability
  _app.mosca.tsx             -> Mosca Readiness
  _app.reports.tsx           -> Reports
  _app.settings.tsx          -> Settings
```

Each route defines its own `head()` with a distinct title + description + og tags. `__root.tsx` gets the AgileGraph title/meta baseline (no `og:image` at root).

## Shared UI components (`src/components/`)

- `app-sidebar.tsx` — sticky left nav, AgileGraph wordmark, nav items (Dashboard, Scan, Graph View, Risk Rankings, Explainability, Mosca, Reports, Settings), collapsible on mobile, active state via `useRouterState`.
- `app-topbar.tsx` — sticky header, breadcrumb/title, search, notifications bell, org switcher, user avatar (visual only).
- `kpi-card.tsx` — icon, label, big value with animated count-up, delta chip, sparkline.
- `chart-card.tsx` — wrapper for Recharts (donut, bar, area, gauge).
- `risk-badge.tsx` — Critical/High/Medium/Low colored pill.
- `empty-state.tsx`, `skeleton.tsx`, `section-header.tsx`, `data-table.tsx` (sortable), `side-panel.tsx` (Sheet), `stepper.tsx`, `gauge.tsx`.

Use existing shadcn primitives already installed (Sidebar, Sheet, Dialog, Button, Card, Table, Tabs, Badge, Progress, Tooltip, Input, etc.). Add `recharts` via `bun add` for charts.

## Placeholder data (`src/lib/mock-data.ts`)

Realistic cybersecurity fixtures used across pages:
- ~40 crypto assets: `auth-service.java`, `payment-api`, TLS certs, RSA-2048, ECC-P256, SHA-1 usages, etc., each with department, algorithm, key size, risk score, recommended PQC algorithm (ML-KEM-768, ML-DSA-65, SLH-DSA), migration effort, connected asset IDs, discovery date.
- Recent scans, activity feed, critical alerts, algorithm usage counts, department distribution, migration progress timeseries.
- Graph: nodes (servers, certs, libraries, code files, sensitive data, applications) + edges.
- Reports list, Mosca inputs/outputs.

## Page-by-page

**Landing (`/`)** — Full-bleed light marketing page: sticky translucent nav, hero with headline "Accelerate Your Post-Quantum Migration", subhead, primary "Start Scan" (→ `/scan`) + secondary "Learn More", hero illustration (SVG graph/network motif). Feature grid (5 cards: Automated Discovery, Graph AI, Risk Prioritization, Explainable AI, Migration Roadmap). "How AgileGraph Works" 4-step stepper. Benefits section (Enterprise Ready, Explainable AI, Fast Analysis, Interactive Dashboard). Trust logos strip. Footer with columns.

**Dashboard (`/dashboard`)** — 7 KPI cards (Total Assets, High/Medium/Low Risk, Migration Progress, PQC Readiness, Recent Scan), animated counters. Charts row: Risk Distribution (donut), Algorithm Usage (horizontal bar), Assets by Department (bar), Migration Progress (area). Recent Activity feed + Critical Alerts side column.

**Scan (`/scan`)** — Tabbed input (Upload ZIP w/ drag-drop, GitHub URL, Domain, Certificate upload). Scan options card. Start/Cancel buttons. In-progress card with animated progress bar + phase log. Recent Scan History table.

**Risk Rankings (`/rankings`)** — Sortable filterable table (search, department filter, risk filter). Columns: Asset, Risk (colored bar + score), Priority, Current Algorithm, Recommended, Migration Time, Risk Reduction, Status. Row click → `/assets/$id`.

**Graph View (`/graph`)** — Interactive SVG graph (custom lightweight force-directed layout with pre-computed positions from mock data — no heavy lib needed). Node colors by risk (green/yellow/orange/red), shapes by type. Left filter panel (type filters, search, zoom controls). Node click → right Sheet panel with Risk Score, Algorithm, Dependencies, Connected Assets, Recommended PQC, Migration Priority.

**Asset Details (`/assets/$id`)** — Header with asset name, badges, actions. Tabs: Overview, Technical Details, Dependencies, Connected Assets, Risk Breakdown, Migration Recommendation. Right column: Timeline + Risk Trend sparkline.

**Explainability (`/explainability`)** — Hero risk score gauge. Cards: "Why was this asset ranked high?", Risk Factors (weighted bars), Graph Influence (mini graph), Connected Assets list. AI Explanation card (structured narrative). Contributing Factors timeline. Small SHAP-style contribution diagram.

**Mosca Readiness (`/mosca`)** — Three input sliders (Confidentiality Lifetime X, Migration Duration Y, Quantum Horizon Z years) with live labels. Big circular gauge with Readiness Score. Formula card (X + Y vs Z). Recommendations list. Timeline visualization comparing X+Y and Z.

**Reports (`/reports`)** — Four generator cards (Executive, Technical, Migration Plan, Risk Summary) with Export PDF / CSV / Print buttons (no-op with toast). Recent Reports table with download icons.

**Settings (`/settings`)** — Left tabs: Theme, Notifications, Scan Preferences, Dashboard Preferences, About. Right panel with grouped setting rows (Switch, Select, Input controls). About shows version, build, credits.

## Micro-interactions

- Framer Motion is NOT added; use CSS transitions + `animate-in`/keyframes for smooth reveals, hover elevate, sidebar slide, count-up hook.
- Loading skeletons on all data cards (visible ~600ms on mount then swap in).
- Hover: card lift + shadow deepen; buttons subtle scale.
- Empty states with icon + copy + CTA.

## Cleanup & installs

- Delete: none needed structurally — rewrite `src/routes/index.tsx` and `src/styles.css`.
- Install: `recharts`, `class-variance-authority` (already present), verify `@radix-ui/react-slider`.
- Update `__root.tsx` meta to AgileGraph title/description and add Inter `<link>` tags.

## Out of scope

No backend, no Lovable Cloud, no auth, no real APIs, no PDF generation. All data static. Report/export/scan buttons show toasts only.
